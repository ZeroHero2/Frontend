<?php
/**
* @package RSForm! Pro
* @copyright (C) 2007-2019 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die;
?>
<button class="btn btn-large btn-primary" id="importFileButton" disabled onclick="Joomla.submitbutton('submissions.importcsv');" type="button"><?php echo JText::_('COM_RSFORM_UPLOAD'); ?></button>