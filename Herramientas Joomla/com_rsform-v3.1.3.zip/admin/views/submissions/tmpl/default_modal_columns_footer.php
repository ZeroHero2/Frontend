<?php
/**
* @package RSForm! Pro
* @copyright (C) 2007-2019 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die;
?>
<button class="btn btn-primary" type="button" onclick="Joomla.submitbutton('submissions.columns')"><?php echo JText::_('COM_RSFORM_SUBMIT'); ?></button>