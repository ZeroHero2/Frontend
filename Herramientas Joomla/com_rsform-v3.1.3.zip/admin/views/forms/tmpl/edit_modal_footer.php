<?php
/**
* @package RSForm! Pro
* @copyright (C) 2007-2019 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die;
?>
<button class="btn btn-success" onclick="RSFormPro.editModal.save();" type="button"><?php echo JText::_('RSFP_SAVE'); ?></button>
<button class="btn btn-secondary" onclick="RSFormPro.editModal.close();" type="button"><?php echo JText::_('RSFP_CLOSE'); ?></button>