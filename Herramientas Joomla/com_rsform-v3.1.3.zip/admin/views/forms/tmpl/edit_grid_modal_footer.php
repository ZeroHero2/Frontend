<?php
/**
* @package RSForm! Pro
* @copyright (C) 2007-2019 www.rsjoomla.com
* @license GPL, http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die;
?>
<button class="btn btn-secondary" onclick="RSFormPro.gridModal.close();" type="button"><?php echo JText::_('RSFP_CLOSE'); ?></button>